import { addDoc, collection, getDocs, query, where } from "firebase/firestore";
import { db } from "../lib/firebase";
import { MAX_TWEET_LENGTH } from "../lib/validators";

const CHIRPS_COLLECTION = "chirps_v2";
const chirpsRef = collection(db, CHIRPS_COLLECTION);
const mapChirp = (snapshot) => ({ id: snapshot.id, ...snapshot.data() });
const newestFirst = (items) => items.sort(
  (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
);

export async function getTweets() {
  const snapshot = await getDocs(chirpsRef);
  return newestFirst(snapshot.docs.map(mapChirp));
}

export async function getTweetsByUser(userId) {
  const result = query(chirpsRef, where("userId", "==", userId));
  const snapshot = await getDocs(result);
  return newestFirst(snapshot.docs.map(mapChirp));
}

export async function createTweet(user, text) {
  const trimmed = (text || "").trim();
  if (!user?.id) throw new Error("Debes iniciar sesión para publicar.");
  if (!trimmed) throw new Error("Escribe algo antes de publicar.");
  if (trimmed.length > MAX_TWEET_LENGTH) {
    throw new Error(`La publicación no puede superar los ${MAX_TWEET_LENGTH} caracteres.`);
  }

  const chirp = {
    userId: user.id,
    username: user.username || "",
    name: user.name || user.username || "Usuario",
    text: trimmed,
    createdAt: new Date().toISOString(),
  };
  const reference = await addDoc(chirpsRef, chirp);
  return { id: reference.id, ...chirp };
}
