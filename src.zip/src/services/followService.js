import {
  collection, deleteDoc, doc, getDoc, getDocs, query, setDoc, where,
} from "firebase/firestore";
import { db } from "../lib/firebase";
import { getUserByUsername, getUsers } from "./userService";

const FOLLOWS_COLLECTION = "follows";
const followsRef = collection(db, FOLLOWS_COLLECTION);

async function getFollowDocuments(field, userId) {
  const result = query(followsRef, where(field, "==", userId));
  const snapshot = await getDocs(result);
  return snapshot.docs.map((item) => ({ id: item.id, ...item.data() }));
}

export async function getFollowingIds(userId) {
  const records = await getFollowDocuments("followerId", userId);
  return records.map((item) => item.followingId);
}

export async function getFollowerIds(userId) {
  const records = await getFollowDocuments("followingId", userId);
  return records.map((item) => item.followerId);
}

export async function getFollowingUsers(userId) {
  const ids = await getFollowingIds(userId);
  if (!ids.length) return [];
  const users = await getUsers();
  return users.filter((item) => ids.includes(item.id));
}

export async function getFollowerUsers(userId) {
  const ids = await getFollowerIds(userId);
  if (!ids.length) return [];
  const users = await getUsers();
  return users.filter((item) => ids.includes(item.id));
}

export async function isFollowing(followerId, followingId) {
  if (!followerId || !followingId) return false;
  const followId = `${followerId}_${followingId}`;
  const snapshot = await getDoc(doc(db, FOLLOWS_COLLECTION, followId));
  return snapshot.exists();
}

export async function followByUsername(currentUser, username) {
  if (!currentUser?.id) throw new Error("Debes iniciar sesión.");
  const target = await getUserByUsername(username);
  if (!target) throw new Error("No encontramos un usuario con ese nombre.");
  if (target.id === currentUser.id) throw new Error("No puedes seguirte a ti mismo.");

  const followId = `${currentUser.id}_${target.id}`;
  const followRef = doc(db, FOLLOWS_COLLECTION, followId);
  const existing = await getDoc(followRef);
  if (existing.exists()) throw new Error("Ya sigues a ese usuario.");

  await setDoc(followRef, {
    followerId: currentUser.id,
    followingId: target.id,
    createdAt: new Date().toISOString(),
  });
  return target;
}

export async function unfollowUser(currentUser, targetId) {
  if (!currentUser?.id) throw new Error("Debes iniciar sesión.");
  if (!targetId || targetId === currentUser.id) return;
  const followId = `${currentUser.id}_${targetId}`;
  await deleteDoc(doc(db, FOLLOWS_COLLECTION, followId));
}
