export const mockFollows = [];
