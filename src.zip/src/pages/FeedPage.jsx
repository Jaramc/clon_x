import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import ChirpCard from "../components/common/ChirpCard";
import EmptyState from "../components/common/EmptyState";
import Spinner from "../components/common/Spinner";
import useAuth from "../hooks/useAuth";
import { getTweets } from "../services/tweetService";
import { getFollowingIds } from "../services/followService";

export default function FeedPage() {
  const { user } = useAuth();
  const location = useLocation();
  const [chirps, setChirps] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    async function loadFeed() {
      if (!user?.id) return;
      setLoading(true);
      setError("");
      try {
        const [allChirps, followedIds] = await Promise.all([
          getTweets(), getFollowingIds(user.id),
        ]);
        if (active) {
          const visibleIds = new Set([user.id, ...followedIds]);
          setChirps(allChirps.filter((chirp) => visibleIds.has(chirp.userId)));
        }
      } catch (err) {
        if (active) setError(err.message || "No se pudo cargar el feed.");
      } finally {
        if (active) setLoading(false);
      }
    }
    loadFeed();
    return () => { active = false; };
  }, [user?.id, location.key]);

  return (
    <section>
      <header className="page-header">
        <h1>Inicio</h1>
        <div className="feed-tabs"><span className="active">Siguiendo</span></div>
      </header>
      {location.state?.notice && <div className="inline-notice">{location.state.notice}</div>}
      {loading ? <Spinner /> : error ? <p className="form-error" role="alert">{error}</p>
        : chirps.length ? chirps.map((chirp) => <ChirpCard key={chirp.id} chirp={chirp} />)
        : <EmptyState title="Tu feed está esperando" description="Sigue a otros usuarios o publica tu primer chirp para comenzar." />}
    </section>
  );
}
