import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import useAuth from "../hooks/useAuth";

export default function LoginPage() {
  const { login, loginGoogle } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (event) => {
    event.preventDefault();
    setError("");
    setBusy(true);
    try {
      await login(email, password);
      navigate("/", { replace: true });
    } catch (err) {
      setError(err.message || "No se pudo iniciar sesión.");
    } finally {
      setBusy(false);
    }
  };

  const google = async () => {
    setError("");
    setBusy(true);
    try {
      await loginGoogle();
      navigate("/", { replace: true });
    } catch (err) {
      setError(err.message || "No se pudo iniciar sesión con Google.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-brand">𝕏</div>
      <h1>Inicia sesión en Clon X</h1>
      <form onSubmit={submit} className="form-stack">
        <label>Correo electrónico
          <input type="email" value={email} onChange={(event) => setEmail(event.target.value)} required autoComplete="email" placeholder="tu@correo.com" />
        </label>
        <label>Contraseña
          <input type="password" value={password} onChange={(event) => setPassword(event.target.value)} required autoComplete="current-password" />
        </label>
        {error && <p className="form-error" role="alert">{error}</p>}
        <button className="button button--wide" disabled={busy}>{busy ? "Ingresando…" : "Iniciar sesión"}</button>
        <div className="or-divider"><span>o</span></div>
        <button type="button" className="button button--google" onClick={google} disabled={busy}>Continuar con Google</button>
      </form>
      <p className="auth-switch">¿No tienes cuenta? <Link to="/register">Regístrate</Link></p>
    </div>
  );
}
