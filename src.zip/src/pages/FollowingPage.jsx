import { useEffect, useState } from "react";
import useAuth from "../hooks/useAuth";
import UserCard from "../components/common/UserCard";
import EmptyState from "../components/common/EmptyState";
import Spinner from "../components/common/Spinner";
import { followByUsername, getFollowingIds, getFollowingUsers } from "../services/followService";

export default function FollowingPage() {
  const { user } = useAuth();
  const [followingIds, setFollowingIds] = useState([]);
  const [users, setUsers] = useState([]);
  const [search, setSearch] = useState("");
  const [target, setTarget] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    if (!user?.id) return;
    setLoading(true);
    try {
      const [ids, followedUsers] = await Promise.all([
        getFollowingIds(user.id),
        getFollowingUsers(user.id),
      ]);
      setFollowingIds(ids);
      setUsers(followedUsers);
    } catch (err) {
      setMessage(err.message || "No se pudo cargar la lista de seguidos.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, [user?.id]);

  const submit = async (event) => {
    event.preventDefault();
    setMessage("");
    setBusy(true);
    try {
      const followed = await followByUsername(user, target);
      setTarget("");
      setMessage(`Ahora sigues a @${followed.username}.`);
      await load();
    } catch (err) {
      setMessage(err.message || "No se pudo seguir a ese usuario.");
    } finally {
      setBusy(false);
    }
  };

  const filteredUsers = users.filter((item) =>
    `${item.name} ${item.username}`.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <section>
      <header className="page-header"><h1>Seguidos</h1></header>
      <form className="follow-search" onSubmit={submit}>
        <label htmlFor="follow-username">Seguir por nombre de usuario</label>
        <div>
          <input id="follow-username" value={target} onChange={(event) => setTarget(event.target.value)} placeholder="@nombredeusuario" required />
          <button className="button" disabled={busy}>{busy ? "Buscando..." : "Seguir"}</button>
        </div>
        {message && <p className={message.startsWith("Ahora") ? "success-message" : "form-error"} role="status">{message}</p>}
      </form>
      <div className="search-box">
        <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Buscar entre los usuarios que sigues" />
      </div>
      {loading ? <Spinner /> :
        filteredUsers.length ? filteredUsers.map((item) =>
          <UserCard key={item.id} user={item} currentUser={user} followingIds={followingIds} onFollowChange={load} />
        ) :
        <EmptyState title="Aún no sigues a nadie" description="Busca un nombre de usuario arriba para comenzar." />}
    </section>
  );
}
