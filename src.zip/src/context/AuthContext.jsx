import { createContext, useEffect, useMemo, useState } from "react";
import { onAuthStateChanged } from "firebase/auth";
import { getUserById } from "../services/userService";
import { auth } from "../lib/firebase";
import { loginUser, logoutUser, registerUser, loginWithGoogle } from "../services/authService";

export const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setLoading(true);
      if (!firebaseUser) {
        if (active) { setUser(null); setLoading(false); }
        return;
      }
      try {
        const profile = await getUserById(firebaseUser.uid);
        if (active) setUser(profile);
      } catch (error) {
        console.error("Failed to load user profile:", error);
        if (active) setUser(null);
      } finally {
        if (active) setLoading(false);
      }
    });
    return () => { active = false; unsubscribe(); };
  }, []);

  const value = useMemo(() => ({
    user,
    loading,
    register: async (values) => { const next = await registerUser(values); setUser(next); return next; },
    login: async (email, password) => { const next = await loginUser(email, password); setUser(next); return next; },
    loginGoogle: async () => { const next = await loginWithGoogle(); setUser(next); return next; },
    logout: async () => { await logoutUser(); setUser(null); },
  }), [user, loading]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
