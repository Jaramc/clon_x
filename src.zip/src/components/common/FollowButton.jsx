import { useState } from "react";
import { followByUsername, unfollowUser } from "../../services/followService";

export default function FollowButton({ user, currentUser, following, onChange }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const click = async () => {
    if (busy) return;
    setBusy(true);
    setError("");

    try {
      if (following) await unfollowUser(currentUser, user.id);
      else await followByUsername(currentUser, user.username);
      await onChange?.();
    } catch (err) {
      setError(err.message || "No se pudo actualizar el seguimiento.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <button
        className={following ? "button button--outline" : "button"}
        onClick={click}
        disabled={busy}
        type="button"
      >
        {busy ? "Procesando..." : following ? "Siguiendo" : "Seguir"}
      </button>
      {error && <small className="form-error" role="alert">{error}</small>}
    </div>
  );
}
